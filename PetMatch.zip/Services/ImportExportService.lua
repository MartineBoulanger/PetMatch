local _, addon = ...

local ImportExportService = {}

local PM_VERSION = "PM1"
local PM_QUEUE_VERSION = "PMQ1"
local BASE32_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUV"
local MAX_IMPORT_BYTES = 250000

local function Trim(value)
  return addon.Utils:Trim(value or "")
end

local function NormalizeNewlines(value)
  value = tostring(value or "")
  value = value:gsub("\r\n", "\n")
  value = value:gsub("\r", "\n")
  return value
end

local function SplitPreservingEmpty(value, separator)
  local result = {}
  local startIndex = 1

  while true do
    local separatorStart, separatorEnd =
        string.find(
          value,
          separator,
          startIndex,
          true
        )

    if not separatorStart then
      result[#result + 1] = string.sub(value, startIndex)
      break
    end

    result[#result + 1] =
        string.sub(
          value,
          startIndex,
          separatorStart - 1
        )

    startIndex = separatorEnd + 1
  end

  return result
end

local function DecodeBase32(value)
  value = string.upper(Trim(value))

  if value == "" then
    return nil
  end

  local result = 0

  for index = 1, #value do
    local character = value:sub(index, index)
    local position = BASE32_ALPHABET:find(character, 1, true)

    if not position then
      return nil
    end

    result = (result * 32) + (position - 1)
  end

  return result
end

local function EncodeBase32(value)
  value = tonumber(value)

  if not value or value < 0 then
    return nil
  end

  value = math.floor(value)

  if value == 0 then
    return "0"
  end

  local result = ""

  while value > 0 do
    local remainder = value % 32

    result =
        BASE32_ALPHABET:sub(
          remainder + 1,
          remainder + 1
        )
        .. result

    value = math.floor(value / 32)
  end

  return result
end

local function ParseNPCIDs(value)
  local npcIDs = {}

  if not value or value == "" then
    return npcIDs
  end

  for encodedID in value:gmatch("[^,]+") do
    local npcID = DecodeBase32(encodedID)

    if npcID then
      npcIDs[#npcIDs + 1] =
          npcID
    end
  end

  return npcIDs
end

local function EncodeNPCIDs(npcIDs)
  if type(npcIDs) ~= "table" then
    return ""
  end

  local encodedIDs = {}

  for _, npcID in ipairs(npcIDs) do
    local encodedID =
        EncodeBase32(npcID)

    if encodedID then
      encodedIDs[#encodedIDs + 1] =
          encodedID
    end
  end

  return table.concat(
    encodedIDs,
    ","
  )
end

local function EncodeRematchNotes(notes)
  notes = tostring(notes or "")

  return notes:gsub(
    "\r\n",
    "\n"
  ):gsub(
    "\r",
    "\n"
  ):gsub(
    "\n",
    "\\n"
  )
end

local function Escape(value)
  value = tostring(value or "")

  return value:gsub(
    "([^%w%-%._ ])",
    function(character)
      return string.format(
        "%%%02X",
        string.byte(character)
      )
    end
  ):gsub(" ", "%%20")
end

local function Unescape(value)
  value = tostring(value or "")

  return value:gsub(
    "%%(%x%x)",
    function(hex)
      return string.char(
        tonumber(hex, 16)
      )
    end
  )
end

local function Split(value, separator)
  local result = {}

  for part in string.gmatch(
    value,
    "([^" .. separator .. "]+)"
  ) do
    result[#result + 1] = part
  end

  return result
end

local function GetOwnedPetsForSpecies(speciesID)
  speciesID = tonumber(speciesID)

  if not speciesID then
    return {}
  end

  local petService = addon.Services and addon.Services.PetJournal

  if not petService then
    return {}
  end

  petService:EnsureIndex()

  local pets = petService.OwnedPetsBySpeciesID
      and petService.OwnedPetsBySpeciesID[speciesID]

  if type(pets) ~= "table" then
    return {}
  end

  return pets
end

local function GetAbilityChoices(
    speciesID,
    selectedAbilities
)
  local abilityIDs =
      C_PetJournal.GetPetAbilityList(
        speciesID
      )

  if type(abilityIDs) ~= "table" then
    return {
      0,
      0,
      0,
    }
  end

  selectedAbilities =
      selectedAbilities or {}

  local choices = {}

  for abilitySlot = 1, 3 do
    local selectedAbilityID =
        selectedAbilities[abilitySlot]

    local firstChoiceID =
        abilityIDs[abilitySlot]

    local secondChoiceID =
        abilityIDs[abilitySlot + 3]

    if not selectedAbilityID then
      choices[abilitySlot] = 0
    elseif selectedAbilityID
        == firstChoiceID then
      choices[abilitySlot] = 1
    elseif selectedAbilityID
        == secondChoiceID then
      choices[abilitySlot] = 2
    else
      choices[abilitySlot] = 0
    end
  end

  return choices
end

local function GetSpeciesID(petGUID)
  if not petGUID then
    return nil
  end

  local pet =
      addon.Services.PetJournal:GetPet(
        petGUID
      )

  return pet and pet.speciesID or nil
end

local function GetPetBreedID(petGUID)
  if type(petGUID) ~= "string" or petGUID == "" then
    return 0
  end

  local breedService = addon.Services and addon.Services.Breed

  if not breedService
      or type(breedService.GetJournalBreedID) ~= "function" then
    return 0
  end

  return tonumber(breedService:GetJournalBreedID(petGUID)) or 0
end

local function ScoreLevellingQueueCandidate(pet, entry, breedID)
  local score = 0

  --------------------------------------------------
  -- Breed is the strongest preference.
  --------------------------------------------------
  if tonumber(entry.breedID)
      and tonumber(entry.breedID) > 0
      and tonumber(breedID) == tonumber(entry.breedID) then
    score = score + 100
  end

  --------------------------------------------------
  -- Prefer the same rarity.
  --------------------------------------------------
  if tonumber(entry.rarity)
      and tonumber(pet.quality) == tonumber(entry.rarity) then
    score = score + 10
  end

  --------------------------------------------------
  -- Prefer the same level.
  --------------------------------------------------
  if tonumber(entry.level)
      and tonumber(pet.level) == tonumber(entry.level) then
    score = score + 1
  end

  return score
end

local function ResolveLevellingQueuePet(entry, unavailablePets, queueService)
  local speciesID = tonumber(entry.speciesID)

  if not speciesID then
    return nil
  end

  local petService = addon.Services and addon.Services.PetJournal

  if not petService then
    return nil
  end

  local pets = GetOwnedPetsForSpecies(speciesID)

  if #pets == 0 then
    return nil
  end

  local bestGUID = nil
  local bestPet = nil
  local bestScore = nil

  for _, petGUID in ipairs(pets) do
    --------------------------------------------------
    -- Only the concrete GUID is excluded.
    --
    -- Another pet of the exact same species,
    -- breed, rarity and level is allowed.
    --------------------------------------------------
    if unavailablePets[petGUID] ~= true then
      local pet = petService:GetPet(petGUID)

      if pet then
        local canAdd = queueService:CanAdd(petGUID)
        local breedID = GetPetBreedID(petGUID)
        local score = ScoreLevellingQueueCandidate(pet, entry, breedID)

        if canAdd then
          local breedID = GetPetBreedID(petGUID)
          local score = ScoreLevellingQueueCandidate(pet, entry, breedID)

          if bestScore == nil or score > bestScore then
            bestGUID = petGUID
            bestPet = pet
            bestScore = score
          end
        end
      end
    end
  end

  if not bestGUID then
    return nil
  end

  --------------------------------------------------
  -- This exact instance may not be used again.
  --------------------------------------------------
  unavailablePets[bestGUID] = true

  return bestGUID, bestPet
end

local function IsBlank(value)
  return addon.Utils:Trim(value or "") == ""
end

local function IsGroupHeader(line)
  return line:match("^__%s*.-%s*__$") ~= nil
end

local function StartsWith(value, prefix)
  return value:sub(1, #prefix) == prefix
end

local function EncodeRematchPetTag(
    team,
    slot
)
  local specialSlot =
      team.specialSlots
      and team.specialSlots[slot]

  if specialSlot then
    local rawPetTag =
        Trim(
          specialSlot.rawPetTag
        )

    if rawPetTag ~= "" then
      return rawPetTag
    end

    if specialSlot.type == "leveling" then
      return "ZL"
    end

    if specialSlot.type == "ignored" then
      return "ZI"
    end

    if specialSlot.type == "random" then
      local petType =
          EncodeBase32(
            specialSlot.petType or 0
          )

      return "ZR" .. (petType or "0")
    end

    if specialSlot.type
        == "levelingQueue" then
      local level =
          EncodeBase32(
            specialSlot.level or 0
          )

      local rarity =
          EncodeBase32(
            specialSlot.rarity or 0
          )

      return "Q"
          .. (level or "0")
          .. (rarity or "0")
    end

    return "ZU"
  end

  local petGUID =
      team.pets
      and team.pets[slot]

  if not petGUID then
    return "ZU"
  end

  local speciesID =
      GetSpeciesID(petGUID)

  if not speciesID then
    return nil,
        string.format(
          "Pet in slot %d could not be found",
          slot
        )
  end

  local choices =
      GetAbilityChoices(
        speciesID,
        team.abilities
        and team.abilities[slot]
      )

  local abilityChoices =
      tostring(choices[1] or 0)
      .. tostring(choices[2] or 0)
      .. tostring(choices[3] or 0)

  local breedID =
      team.breeds
      and team.breeds[slot]
      or 0

  local encodedBreed =
      EncodeBase32(breedID)

  local encodedSpecies =
      EncodeBase32(speciesID)

  if not encodedBreed
      or not encodedSpecies then
    return nil,
        string.format(
          "Pet in slot %d could not be encoded",
          slot
        )
  end

  return abilityChoices
      .. encodedBreed
      .. encodedSpecies
end

local function SplitNotesAndScript(text)
  if type(text) == "table" then
    text = table.concat(text, ":")
  end

  text = text or ""

  -- Ondersteun imports waarin \n letterlijk
  -- als twee tekens voorkomt.
  text = text:gsub("\\r\\n", "\n")
  text = text:gsub("\\n", "\n")

  local beginMarker =
  "-----BEGIN PET BATTLE SCRIPT-----"

  local endMarker =
  "-----END PET BATTLE SCRIPT-----"

  local beginPos =
      text:find(
        beginMarker,
        1,
        true
      )

  if not beginPos then
    return Trim(text), ""
  end

  local scriptStart =
      beginPos + #beginMarker

  local endPos =
      text:find(
        endMarker,
        scriptStart,
        true
      )

  -- Geen geldige afsluitende marker:
  -- laat de volledige tekst als notes staan.
  if not endPos then
    return Trim(text), ""
  end

  local notes =
      Trim(
        text:sub(
          1,
          beginPos - 1
        )
      )

  local script =
      Trim(
        text:sub(
          scriptStart,
          endPos - 1
        )
      )

  return notes, script
end

local function BuildRematchNotes(notes, script)
  notes = Trim(notes or "")
  script = Trim(script or "")

  if script == "" then
    return notes
  end

  if notes ~= "" then
    return table.concat({
      notes,
      "",
      "-----BEGIN PET BATTLE SCRIPT-----",
      script,
      "-----END PET BATTLE SCRIPT-----",
    }, "\n")
  end

  return table.concat({
    "-----BEGIN PET BATTLE SCRIPT-----",
    script,
    "-----END PET BATTLE SCRIPT-----",
  }, "\n")
end

local function GetSpeciesName(speciesID)
  speciesID = tonumber(speciesID)

  if not speciesID then
    return "Unknown pet"
  end

  local speciesName =
      C_PetJournal.GetPetInfoBySpeciesID(
        speciesID
      )

  return speciesName or ("Species " .. speciesID)
end

local function GetRequiredSpeciesCounts(teamData)
  local counts = {}

  for slot = 1, 3 do
    local slotData = teamData.slots and teamData.slots[slot]

    if slotData and not slotData.special and slotData.speciesID then
      local speciesID = tonumber(slotData.speciesID)

      if speciesID then
        counts[speciesID] = (counts[speciesID] or 0) + 1
      end
    end
  end

  return counts
end

local function GetResolvedSpeciesCounts(team)
  local counts = {}

  for slot = 1, 3 do
    local petGUID = team and team.pets and team.pets[slot]

    if petGUID then
      local speciesID = addon.Services.PetJournal:GetSpeciesID(petGUID)

      speciesID = tonumber(speciesID)

      if speciesID then
        counts[speciesID] = (counts[speciesID] or 0) + 1
      end
    end
  end

  return counts
end

local function FindRematchCore(service, fields)
  if type(fields) ~= "table" then
    return nil
  end

  for pet1Index = 3, #fields - 2 do
    local petTag1 = fields[pet1Index]
    local petTag2 = fields[pet1Index + 1]
    local petTag3 = fields[pet1Index + 2]

    if petTag1 ~= "" and petTag2 ~= "" and petTag3 ~= "" then
      local slot1 = service:DecodeRematchPetTag(petTag1)
      local slot2 = service:DecodeRematchPetTag(petTag2)
      local slot3 = service:DecodeRematchPetTag(petTag3)

      if slot1 and slot2 and slot3 then
        local targetIndex = pet1Index - 1
        local nameEndIndex = targetIndex - 1

        if nameEndIndex >= 1 then
          return {
            nameEndIndex = nameEndIndex,
            targetIndex = targetIndex,
            pet1Index = pet1Index,
            afterPetsIndex = pet1Index + 3,
          }
        end
      end
    end
  end

  return nil
end

function ImportExportService:NeedsPreview(
    document
)
  if not document
      or not document.groups then
    return false
  end

  local groupCount = 0
  local teamCount = 0
  local hasFolderHeader = false

  for _, group in ipairs(
    document.groups
  ) do
    groupCount = groupCount + 1

    if group.name
        and addon.Utils:Trim(
          group.name
        ) ~= "" then
      hasFolderHeader = true
    end

    for _ in ipairs(
      group.teams or {}
    ) do
      teamCount = teamCount + 1
    end
  end

  return hasFolderHeader
      or groupCount > 1
      or teamCount > 1
end

function ImportExportService:IsRematchTeam(text)
  if type(text) ~= "string" then
    return false
  end

  local firstLine = text:match("([^\r\n]+)")

  if not firstLine then
    return false
  end

  local fields = SplitPreservingEmpty(firstLine, ":")
  local core = FindRematchCore(self, fields)

  return core ~= nil
end

function ImportExportService:ExportTeam(team)
  if not team then
    return nil, "Team not found"
  end

  local parts = {
    PM_VERSION,
    "name=" .. Escape(
      team.name or "Imported Team"
    ),
    "favorite="
    .. (
      team.favorite
      and "1"
      or "0"
    ),
  }

  if team.folderID then
    local folder =
        addon.Services.Folder:Get(
          team.folderID
        )

    if folder then
      parts[#parts + 1] =
          "folder="
          .. Escape(folder.name)
    end
  end

  for slot = 1, 3 do
    local speciesID =
        GetSpeciesID(
          team.pets
          and team.pets[slot]
        )

    local abilities =
        team.abilities
        and team.abilities[slot]
        or {}

    parts[#parts + 1] =
        string.format(
          "slot%d=%s,%s,%s,%s",
          slot,
          tostring(speciesID or 0),
          tostring(abilities[1] or 0),
          tostring(abilities[2] or 0),
          tostring(abilities[3] or 0)
        )
  end

  return table.concat(parts, "|")
end

function ImportExportService:ParsePetMatch(value)
  value = Trim(value)

  if value:sub(1, 4) ~= "PM1|" then
    return nil, "Not a PetMatch PM1 string"
  end

  local fields = Split(value, "|")

  local result = {
    format = "petmatch",
    name = "Imported Team",
    favorite = false,
    folderName = nil,
    slots = {},
  }

  for index = 2, #fields do
    local key, rawValue =
        fields[index]:match(
          "^([^=]+)=(.*)$"
        )

    if key then
      if key == "name" then
        result.name =
            Unescape(rawValue)
      elseif key == "folder" then
        result.folderName =
            Unescape(rawValue)
      elseif key == "favorite" then
        result.favorite =
            rawValue == "1"
      else
        local slot =
            tonumber(
              key:match("^slot([123])$")
            )

        if slot then
          local values =
              Split(rawValue, ",")

          result.slots[slot] = {
            speciesID =
                tonumber(values[1]),

            abilities = {
              tonumber(values[2]),
              tonumber(values[3]),
              tonumber(values[4]),
            },
          }
        end
      end
    end
  end

  return result
end

function ImportExportService:Parse(value)
  value = Trim(value)

  if value == "" then
    return nil, "Paste a team string"
  end

  if #value > MAX_IMPORT_BYTES then
    return nil,
        "The import string is too large. "
        .. "Maximum size is "
        .. MAX_IMPORT_BYTES
        .. " bytes."
  end

  local format = self:DetectFormat(value)

  if format == "petmatch" then
    return self:ParsePetMatch(value)
  elseif format == "rematch" then
    return self:ParseRematchTeam(value)
  end

  return nil, "Unknown team format"
end

function ImportExportService:Import(
    value,
    options
)
  options = options or {}

  value = Trim(value)

  local format = self:DetectFormat(value)

  if format == "rematch" then
    return self:ImportRematch(
      value,
      options
    )
  end

  if format == "petmatch" then
    if not self.ImportPetMatch then
      return nil,
          "PetMatch-import wordt nog niet ondersteund."
    end

    return self:ImportPetMatch(
      value,
      options
    )
  end

  return nil,
      "Het importformaat kon niet worden herkend."
end

function ImportExportService:GetAbilityIDsFromChoices(
    speciesID,
    choices
)
  local abilityIDs = C_PetJournal.GetPetAbilityList(speciesID)

  if type(abilityIDs) ~= "table" then
    return {}
  end

  local selected = {}

  for abilitySlot = 1, 3 do
    local choice = choices[abilitySlot] or 0

    if choice == 1 then
      selected[abilitySlot] = abilityIDs[abilitySlot]
    elseif choice == 2 then
      selected[abilitySlot] = abilityIDs[abilitySlot + 3]
    else
      -- 0 betekent dat Rematch geen voorkeur opslaat.
      selected[abilitySlot] = nil
    end
  end

  return selected
end

function ImportExportService:ImportRematchDocument(document, options)
  options = options or {}

  local defaultFolderID = nil

  if options.defaultFolderSpecified == true then
    defaultFolderID = options.defaultFolderID
  end

  local conflictMode =
      options.conflictMode
      or addon.Settings:Get(
        "duplicateTeamMode"
      )
      or "replace"

  local result = {
    teams = {},
    folders = {},
    warnings = {},
    failed = {},
    missingSpecies = {},
  }

  local resolvedPetsBySpeciesID = {}

  for _, groupData in ipairs(document.groups or {}) do
    local folderID = defaultFolderID

    if groupData.name then
      if string.lower(
            addon.Utils:Trim(groupData.name)
          ) == "unsorted" then
        folderID = nil
      else
        local folder =
            addon.Services.Folder:FindByName(
              groupData.name
            )

        if not folder then
          folder =
              addon.Services.Folder:Create(
                groupData.name
              )
        end

        if folder then
          folderID = folder.id

          result.folders[
          #result.folders + 1
          ] = folder
        else
          result.warnings[
          #result.warnings + 1
          ] =
              "Unable to create folder: "
              .. groupData.name
        end
      end
    end

    for _, teamData in ipairs(groupData.teams or {}) do
      teamData.folderID = folderID

      local team, errorMessage, missingSpecies =
          addon.Services.Team:CreateFromImport(
            teamData,
            {
              conflictMode = conflictMode,
              resolvedPetsBySpeciesID = resolvedPetsBySpeciesID
            }
          )

      if team then
        result.teams[#result.teams + 1] = team

        if missingSpecies and #missingSpecies > 0 then
          local requiredCounts = GetRequiredSpeciesCounts(teamData)
          local resolvedCounts = GetResolvedSpeciesCounts(team)

          local handledSpecies = {}

          for _, speciesID in ipairs(missingSpecies) do
            speciesID = tonumber(speciesID)

            if speciesID and not handledSpecies[speciesID] then
              handledSpecies[speciesID] = true

              local required = requiredCounts[speciesID] or 1
              local assigned = resolvedCounts[speciesID] or 0
              local petName = GetSpeciesName(speciesID)

              local warning

              if required > 1 then
                warning =
                    string.format(
                      "%s requires %d copies of %s, but only %d could be assigned.",
                      teamData.name
                      or "Imported team",
                      required,
                      petName,
                      assigned
                    )
              else
                warning =
                    string.format(
                      "%s requires %s, but no owned pet could be assigned.",
                      teamData.name
                      or "Imported team",
                      petName
                    )
              end

              result.warnings[#result.warnings + 1] = warning

              addon.Logger:Warn(
                warning
              )
            end
          end
        end
      else
        result.failed[#result.failed + 1] = {
          name = teamData.name,
          error = errorMessage,
        }

        if errorMessage then
          result.warnings[#result.warnings + 1] = errorMessage
        end
      end

      for _, speciesID in ipairs(missingSpecies or {}) do
        result.missingSpecies[#result.missingSpecies + 1] = speciesID
      end
    end
  end

  return result
end

function ImportExportService:ImportRematchDocumentAsync(document, options)
  options = options or {}

  local defaultFolderID = nil

  if options.defaultFolderSpecified == true then
    defaultFolderID = options.defaultFolderID
  end

  local conflictMode =
      options.conflictMode
      or addon.Settings:Get(
        "duplicateTeamMode"
      )
      or "replace"

  local batchSize =
      tonumber(options.batchSize)
      or 5

  local onProgress =
      options.onProgress

  local onComplete =
      options.onComplete

  local onError =
      options.onError

  local result = {
    teams = {},
    folders = {},
    warnings = {},
    failed = {},
    missingSpecies = {},
  }

  --------------------------------------------------
  -- Flatten groups into work items
  --------------------------------------------------

  local workItems = {}

  for _, groupData in ipairs(
    document.groups or {}
  ) do
    local folderID = defaultFolderID

    if groupData.name then
      if string.lower(
            addon.Utils:Trim(
              groupData.name
            )
          ) == "unsorted" then
        folderID = nil
      else
        local folder =
            addon.Services.Folder:
            FindByName(
              groupData.name
            )

        if not folder then
          folder =
              addon.Services.Folder:
              Create(
                groupData.name
              )
        end

        if folder then
          folderID =
              folder.id

          result.folders[
          #result.folders + 1
          ] =
              folder
        else
          result.warnings[
          #result.warnings + 1
          ] =
              "Unable to create folder: "
              .. groupData.name
        end
      end
    end

    for _, teamData in ipairs(
      groupData.teams or {}
    ) do
      workItems[
      #workItems + 1
      ] = {
        teamData =
            teamData,

        folderID =
            folderID,
      }
    end
  end

  local total =
      #workItems

  if total == 0 then
    if onError then
      onError(
        "No teams selected."
      )
    end

    return
  end

  local resolvedPetsBySpeciesID = {}
  local index = 1

  --------------------------------------------------
  -- Finish
  --------------------------------------------------

  local function Finish()
    if onProgress then
      onProgress(
        1,
        total,
        total
      )
    end

    if onComplete then
      onComplete(
        result
      )
    end
  end

  --------------------------------------------------
  -- Process a batch
  --------------------------------------------------

  local function ProcessBatch()
    local processed = 0

    while index <= total
      and processed < batchSize
    do
      local item =
          workItems[index]

      local teamData =
          item.teamData

      teamData.folderID =
          item.folderID

      local team, errorMessage, missingSpecies =
          addon.Services.Team:CreateFromImport(
            teamData,
            {
              conflictMode = conflictMode,
              resolvedPetsBySpeciesID = resolvedPetsBySpeciesID,
            }
          )

      if team and missingSpecies and #missingSpecies > 0 then
        addon.Logger:Warn(
          "Imported team is missing one or more required pets."
        )

        local requiredCounts = GetRequiredSpeciesCounts(teamData)
        local resolvedCounts = GetResolvedSpeciesCounts(team)

        local handledSpecies = {}

        for _, speciesID in ipairs(missingSpecies) do
          speciesID = tonumber(speciesID)

          if speciesID and not handledSpecies[speciesID] then
            handledSpecies[speciesID] = true

            local required = requiredCounts[speciesID] or 1
            local assigned = resolvedCounts[speciesID] or 0
            local petName = GetSpeciesName(speciesID)

            local warning

            if required > 1 then
              warning =
                  string.format(
                    "%s requires %d copies of %s, but only %d could be assigned.",
                    teamData.name
                    or "Imported team",
                    required,
                    petName,
                    assigned
                  )
            else
              warning =
                  string.format(
                    "%s requires %s, but no owned pet could be assigned.",
                    teamData.name
                    or "Imported team",
                    petName
                  )
            end

            result.warnings[#result.warnings + 1] = warning

            addon.Logger:Warn(
              warning
            )
          end
        end
      end

      if team then
        result.teams[#result.teams + 1] = team
      else
        result.failed[#result.failed + 1] = {
          name = teamData.name,
          error = errorMessage,
        }

        if errorMessage then
          result.warnings[#result.warnings + 1] = errorMessage
        end
      end

      for _, speciesID in ipairs(missingSpecies or {}) do
        result.missingSpecies[#result.missingSpecies + 1] = speciesID
      end

      index = index + 1
      processed = processed + 1
    end

    --------------------------------------------------
    -- Progress
    --------------------------------------------------

    local completed = math.min(index - 1, total)

    if onProgress then
      onProgress(
        completed / total,
        completed,
        total
      )
    end

    --------------------------------------------------
    -- Continue next frame
    --------------------------------------------------

    if index <= total then
      C_Timer.After(
        0,
        ProcessBatch
      )

      return
    end

    Finish()
  end

  C_Timer.After(
    0,
    ProcessBatch
  )
end

function ImportExportService:DecodeRematchPetTag(token)
  token = string.upper(Trim(token))

  if token == "" then
    return nil, "Empty Rematch pet tag"
  end

  -- Speciale Rematch-slots.
  if token == "ZL" then
    return {
      type = "leveling",
      special = true,
      rawPetTag = token,
    }
  end

  if token == "ZI" then
    return {
      type = "ignored",
      special = true,
      rawPetTag = token,
    }
  end

  if token == "ZU" then
    return {
      type = "unknown",
      special = true,
      rawPetTag = token,
    }
  end

  local randomTypeCode = token:match("^ZR([0-9A-V])$")

  if randomTypeCode then
    return {
      type = "random",
      special = true,
      petType = DecodeBase32(randomTypeCode),
      rawPetTag = token,
    }
  end

  if token:sub(1, 1) == "Q" then
    if #token < 3 then
      return nil, "Invalid leveling queue tag: " .. token
    end

    local level = DecodeBase32(token:sub(2, 2))
    local rarity = DecodeBase32(token:sub(3, 3))

    if not level or not rarity then
      return nil, "Invalid leveling queue tag: " .. token
    end

    return {
      type = "levelingQueue",
      special = true,
      level = level,
      rarity = rarity,
      rawPetTag = token,
    }
  end

  if #token < 5 then
    return nil, "Invalid Rematch pet tag: " .. token
  end

  local choices = {
    DecodeBase32(token:sub(1, 1)),
    DecodeBase32(token:sub(2, 2)),
    DecodeBase32(token:sub(3, 3)),
  }

  for abilitySlot = 1, 3 do
    local choice = choices[abilitySlot]

    if choice ~= 0
        and choice ~= 1
        and choice ~= 2 then
      return nil,
          "Invalid Rematch ability choice"
    end
  end

  local breedID = DecodeBase32(token:sub(4, 4))
  local speciesID = DecodeBase32(token:sub(5))

  if not speciesID then
    return nil, "Invalid Rematch species code"
  end

  return {
    type = "pet",
    special = false,
    speciesID = speciesID,
    breedID = breedID or 0,
    abilityChoices = choices,
    abilities =
        self:GetAbilityIDsFromChoices(
          speciesID,
          choices
        ),
    rawPetTag = token,
  }
end

function ImportExportService:ParseRematchTeam(line)
  line = Trim(line)

  local fields = SplitPreservingEmpty(line, ":")

  if #fields < 6 then
    return nil, "Incomplete Rematch team string"
  end

  --------------------------------------------------
  -- Locate Rematch core
  --------------------------------------------------
  local core = FindRematchCore(self, fields)

  if not core then
    return nil, "Unable to locate Rematch pet slots"
  end

  --------------------------------------------------
  -- Team name
  --
  -- Everything before the target field belongs
  -- to the team name. This allows ':' in names.
  --------------------------------------------------
  local nameParts = {}

  for index = 1, core.nameEndIndex do
    nameParts[#nameParts + 1] = fields[index]
  end

  local name = Trim(table.concat(nameParts, ":"))

  if name == "" then
    return nil, "Rematch team has no name"
  end

  --------------------------------------------------
  -- Target
  --------------------------------------------------
  local targetTag = fields[core.targetIndex] or ""

  --------------------------------------------------
  -- Result
  --------------------------------------------------
  local result = {
    format = "rematch",
    name = name,
    npcIDs = ParseNPCIDs(targetTag),
    slots = {},
    preferences = nil,
    notes = "",
    script = "",
    warnings = {},
  }

  --------------------------------------------------
  -- Pets
  --------------------------------------------------
  for slot = 1, 3 do
    local token = fields[core.pet1Index + slot - 1]

    if token and token ~= "" then
      local slotData,
      errorMessage = self:DecodeRematchPetTag(token)

      if slotData then
        result.slots[slot] = slotData
      else
        result.warnings[#result.warnings + 1] = errorMessage
      end
    end
  end

  --------------------------------------------------
  -- Preferences / notes / script
  --------------------------------------------------
  local index = core.afterPetsIndex

  while index <= #fields do
    local marker = fields[index]

    if marker == "P" then
      result.preferences = {
        minHP = tonumber(fields[index + 1]),
        allowMM = tonumber(fields[index + 2]),
        expectedDD = tonumber(fields[index + 3]),
        minXP = tonumber(fields[index + 4]),
        maxXP = tonumber(fields[index + 5]),
      }

      index = index + 6
    elseif marker == "N" then
      local noteParts = {}

      for noteIndex = index + 1, #fields do
        noteParts[#noteParts + 1] = fields[noteIndex]
      end

      local noteText = table.concat(noteParts, ":")
      local notes, script = SplitNotesAndScript(noteText)

      result.notes = notes
      result.script = script

      break
    else
      index = index + 1
    end
  end

  return result
end

function ImportExportService:ParseRematchGroupHeader(line)
  local inner = Trim(line:match("^__%s*(.-)%s*__$"))

  if not inner or inner == "" then
    return nil, "Rematch group has no name"
  end

  if not inner:find(":", 1, true) then
    return {
      name = inner,
      teams = {},
    }
  end

  local fields = SplitPreservingEmpty(inner, ":")

  return {
    name = Trim(fields[1]),
    sort = tonumber(fields[2]),
    icon = fields[3] ~= "" and fields[3] or nil,
    color = fields[4] ~= "" and fields[4] or nil,
    teams = {},
  }
end

function ImportExportService:ParseRematchDocument(value)
  value = NormalizeNewlines(value)

  if IsBlank(value) then
    return nil, "Paste a Rematch team or group export"
  end

  local document = {
    format = "rematch",
    groups = {},
    warnings = {},
  }

  local ungrouped = {
    name = nil,
    teams = {},
  }

  local currentGroup = ungrouped

  for rawLine in value:gmatch("([^\n]*)\n?") do
    local line = addon.Utils:Trim(rawLine)

    if line ~= "" then
      if IsGroupHeader(line) then
        local group, errorMessage =
            self:ParseRematchGroupHeader(line)

        if not group then
          document.warnings[#document.warnings + 1] =
              errorMessage
        else
          document.groups[#document.groups + 1] =
              group

          currentGroup = group
        end
      else
        local team, errorMessage =
            self:ParseRematchTeam(line)

        if team then
          currentGroup.teams[#currentGroup.teams + 1] =
              team
        else
          document.warnings[#document.warnings + 1] =
              errorMessage
              or ("Unable to parse line: " .. line)
        end
      end
    end
  end

  if #ungrouped.teams > 0 then
    table.insert(document.groups, 1, ungrouped)
  end

  local teamCount = 0

  for _, group in ipairs(document.groups) do
    teamCount = teamCount + #group.teams
  end

  if teamCount == 0 then
    return nil, "No valid Rematch teams were found"
  end

  return document
end

function ImportExportService:ParseRematchDocumentAsync(value, options)
  options = options or {}

  local onProgress =
      options.onProgress

  local onComplete =
      options.onComplete

  local onError =
      options.onError

  local batchSize =
      tonumber(
        options.batchSize
      )
      or 25

  value =
      NormalizeNewlines(
        value
      )

  if IsBlank(value) then
    if onError then
      onError(
        "Paste a Rematch team or group export"
      )
    end

    return
  end

  --------------------------------------------------
  -- Build line list
  --------------------------------------------------
  local lines = {}

  for rawLine in
  value:gmatch(
    "([^\n]*)\n?"
  )
  do
    lines[#lines + 1] =
        rawLine
  end

  local total =
      #lines

  --------------------------------------------------
  -- Document
  --------------------------------------------------
  local document = {
    format = "rematch",
    groups = {},
    warnings = {},
  }

  local ungrouped = {
    name = nil,
    teams = {},
  }

  local currentGroup =
      ungrouped

  local index = 1

  --------------------------------------------------
  -- Finish
  --------------------------------------------------
  local function Finish()
    if #ungrouped.teams > 0 then
      table.insert(
        document.groups,
        1,
        ungrouped
      )
    end

    local teamCount = 0

    for _, group in ipairs(
      document.groups
    ) do
      teamCount =
          teamCount
          + #group.teams
    end

    if teamCount == 0 then
      if onError then
        onError(
          "No valid Rematch teams were found"
        )
      end

      return
    end

    if onProgress then
      onProgress(
        1,
        total,
        total
      )
    end

    if onComplete then
      onComplete(
        document
      )
    end
  end

  --------------------------------------------------
  -- Process batch
  --------------------------------------------------
  local function ProcessBatch()
    local processed = 0

    while index <= total
      and processed < batchSize
    do
      local rawLine =
          lines[index]

      local line =
          addon.Utils:Trim(
            rawLine
          )

      if line ~= "" then
        if IsGroupHeader(line) then
          local group,
          errorMessage =
              self:
              ParseRematchGroupHeader(
                line
              )

          if not group then
            document.warnings[
            #document.warnings + 1
            ] =
                errorMessage
          else
            document.groups[
            #document.groups + 1
            ] =
                group

            currentGroup =
                group
          end
        else
          local team,
          errorMessage =
              self:
              ParseRematchTeam(
                line
              )

          if team then
            currentGroup.teams[
            #currentGroup.teams + 1
            ] =
                team
          else
            document.warnings[
            #document.warnings + 1
            ] =
                errorMessage
                or (
                  "Unable to parse line: "
                  .. line
                )
          end
        end
      end

      index =
          index + 1

      processed =
          processed + 1
    end

    --------------------------------------------------
    -- Progress
    --------------------------------------------------

    if onProgress then
      local completed =
          math.min(
            index - 1,
            total
          )

      local progress = 1

      if total > 0 then
        progress =
            completed
            / total
      end

      onProgress(
        progress,
        completed,
        total
      )
    end

    --------------------------------------------------
    -- Continue next frame
    --------------------------------------------------

    if index <= total then
      C_Timer.After(
        0,
        ProcessBatch
      )

      return
    end

    Finish()
  end

  --------------------------------------------------
  -- Start next frame
  --------------------------------------------------

  C_Timer.After(
    0,
    ProcessBatch
  )
end

function ImportExportService:ImportRematch(
    value,
    options
)
  local document, errorMessage =
      self:ParseRematchDocument(value)

  if not document then
    return nil, errorMessage
  end

  options = options or {}

  return self:ImportRematchDocument(
    document,
    options
  )
end

function ImportExportService:DetectFormat(value)
  value = Trim(value)

  if value == "" then
    return nil
  end

  if StartsWith(value, "PM1") then
    return "petmatch"
  end

  local firstLine = value:match("([^\r\n]+)")

  if firstLine then
    firstLine = Trim(firstLine)

    if firstLine:match("^__%s*.-%s*__$") then
      return "rematch"
    end

    local fields =
        SplitPreservingEmpty(
          firstLine,
          ":"
        )

    if #fields >= 6 then
      return "rematch"
    end
  end

  return nil
end

function ImportExportService:PrepareImport(
    value
)
  local format =
      self:DetectFormat(value)

  if not format then
    return nil,
        "Het importformaat kon niet worden herkend."
  end

  if format == "rematch" then
    local document, errorMessage =
        self:ParseRematchDocument(value)

    if not document then
      return nil, errorMessage
    end

    return {
      format = format,
      document = document,
      requiresPreview =
          self:NeedsPreview(document),
    }
  end

  return {
    format = format,
    value = value,
    requiresPreview = false,
  }
end

function ImportExportService:PrepareImportAsync(
    value,
    options
)
  options = options or {}

  local onComplete =
      options.onComplete

  local onError =
      options.onError

  local onProgress =
      options.onProgress

  local format =
      self:DetectFormat(
        value
      )

  if not format then
    if onError then
      onError(
        "Het importformaat kon niet worden herkend."
      )
    end

    return
  end

  --------------------------------------------------
  -- Rematch
  --------------------------------------------------

  if format == "rematch" then
    self:ParseRematchDocumentAsync(
      value,
      {
        batchSize =
            options.batchSize,

        onProgress =
            onProgress,

        onError =
            onError,

        onComplete =
            function(document)
              if not onComplete then
                return
              end

              onComplete({
                format =
                    format,

                document =
                    document,

                requiresPreview =
                    self:
                    NeedsPreview(
                      document
                    ),
              })
            end,
      }
    )

    return
  end

  --------------------------------------------------
  -- PetMatch
  --------------------------------------------------

  if onProgress then
    onProgress(
      1,
      1,
      1
    )
  end

  if onComplete then
    onComplete({
      format =
          format,

      value =
          value,

      requiresPreview =
          false,
    })
  end
end

function ImportExportService:ExportRematchTeam(
    team
)
  if not team then
    return nil, "Team not found"
  end

  local name =
      Trim(
        team.name or ""
      )

  if name == "" then
    return nil, "Team has no name"
  end

  name = name:gsub(":", " -")

  local petTags = {}

  for slot = 1, 3 do
    local petTag, errorMessage =
        EncodeRematchPetTag(
          team,
          slot
        )

    if not petTag then
      return nil, errorMessage
    end

    petTags[slot] = petTag
  end

  local npcIDs =
      EncodeNPCIDs(
        team.targetNPCIDs
      )

  local result =
      table.concat(
        {
          name,
          npcIDs,
          petTags[1],
          petTags[2],
          petTags[3],
          "",
        },
        ":"
      )

  local notes =
      EncodeRematchNotes(
        BuildRematchNotes(
          team.notes,
          team.script
        )
      )

  if notes ~= "" then
    result =
        result
        .. ":N:"
        .. notes
  end

  return result
end

function ImportExportService:ExportAll()
  local lines = {}

  local folders =
      addon.Services.Folder:GetSortedFolders()

  local allTeams =
      addon.Services.Team:GetAllTeams()

  for _, folder in ipairs(folders) do
    local teams = {}

    for _, team in pairs(allTeams) do
      if team.folderID == folder.id then
        teams[#teams + 1] = team
      end
    end

    if #teams > 0 then
      lines[#lines + 1] =
          "__ " .. folder.name .. " __"

      for _, team in ipairs(teams) do
        local exportString,
        errorMessage =
            self:ExportRematchTeam(team)

        if not exportString then
          return nil,
              errorMessage
              or (
                "Unable to export team: "
                .. tostring(team.name)
              )
        end

        lines[#lines + 1] = exportString
      end

      lines[#lines + 1] = ""
    end
  end

  local unsortedTeams = {}

  for _, team in pairs(allTeams) do
    local folderID = team.folderID

    local isUnsorted =
        folderID == nil
        or folderID == ""
        or folderID
        == addon.Services.Folder.UNSORTED

    if isUnsorted then
      unsortedTeams[#unsortedTeams + 1] =
          team
    end
  end

  if #unsortedTeams > 0 then
    lines[#lines + 1] =
    "__ Unsorted __"

    for _, team in ipairs(unsortedTeams) do
      local exportString,
      errorMessage =
          self:ExportRematchTeam(team)

      if not exportString then
        return nil,
            errorMessage
            or (
              "Unable to export team: "
              .. tostring(team.name)
            )
      end

      lines[#lines + 1] = exportString
    end

    lines[#lines + 1] = ""
  end

  while lines[#lines] == "" do
    table.remove(lines)
  end

  if #lines == 0 then
    return nil,
        "No teams were found to export"
  end

  return table.concat(lines, "\n")
end

function ImportExportService:ExportFolder(
    folderKey
)
  local folder =
      addon.Services.Folder:Get(folderKey)

  if not folder then
    return nil, "Folder was not found"
  end

  local teams = {}

  for _, team in pairs(
    addon.Services.Team:GetAllTeams()
  ) do
    if team.folderID == folder.id then
      teams[#teams + 1] = team
    end
  end

  if #teams == 0 then
    return nil, "Folder contains no teams"
  end

  local lines = {
    "__ " .. folder.name .. " __",
  }

  for _, team in ipairs(teams) do
    local exportString,
    errorMessage =
        self:ExportRematchTeam(team)

    if not exportString then
      return nil,
          errorMessage
          or (
            "Unable to export team: "
            .. tostring(team.name)
          )
    end

    lines[#lines + 1] = exportString
  end

  return table.concat(lines, "\n")
end

function ImportExportService:ExportLevellingQueue()
  local queueService = addon.Services and addon.Services.LevellingQueue

  if not queueService then
    return nil, "Levelling queue service is not available."
  end

  local petService = addon.Services and addon.Services.PetJournal

  if not petService then
    return nil, "Pet Journal service is not available."
  end

  local queue = queueService:GetAll()

  if type(queue) ~= "table" or #queue == 0 then
    return nil, "The levelling queue is empty."
  end

  local lines = { PM_QUEUE_VERSION }

  for _, petGUID in ipairs(queue) do
    local pet = petService:GetPet(petGUID)

    if not pet then
      return nil, "A pet in the levelling queue could not be found."
    end

    local speciesID = tonumber(pet.speciesID)

    if not speciesID then
      return nil, "A pet in the levelling queue has no species ID."
    end

    local breedID = GetPetBreedID(petGUID)
    local level = tonumber(pet.level) or 0
    local rarity = tonumber(pet.quality) or 0
    local petType = tonumber(pet.petType) or 0

    lines[#lines + 1] =
        string.format(
          "species=%d;breed=%d;level=%d;rarity=%d;type=%d",
          speciesID,
          tonumber(breedID) or 0,
          level,
          rarity,
          petType
        )
  end

  return table.concat(
    lines,
    "\n"
  )
end

function ImportExportService:ParseLevellingQueue(value)
  value = NormalizeNewlines(tostring(value or ""))

  value = Trim(value)

  if value == "" then
    return nil, "Paste a levelling queue."
  end

  if #value > MAX_IMPORT_BYTES then
    return nil, "The import is too large."
  end

  local lines = {}

  for line in value:gmatch("[^\n]+") do
    line = Trim(line)
    if line ~= "" then
      lines[#lines + 1] = line
    end
  end

  if #lines == 0 or lines[1] ~= PM_QUEUE_VERSION then
    return nil, "Not a PetMatch levelling queue."
  end

  local result = {
    format = "petmatchQueue",
    version = PM_QUEUE_VERSION,
    pets = {},
    warnings = {},
  }

  for index = 2, #lines do
    local line = lines[index]

    local speciesText,
    breedText,
    levelText,
    rarityText,
    typeText =
        line:match(
          "^species=(%d+);breed=(%d+);level=(%d+);rarity=(%d+);type=(%d+)$"
        )

    local speciesID = tonumber(speciesText)

    if speciesID then
      result.pets[#result.pets + 1] = {
        speciesID = speciesID,
        breedID = tonumber(breedText) or 0,
        level = tonumber(levelText) or 0,
        rarity = tonumber(rarityText) or 0,
        petType = tonumber(typeText) or 0,
        sourceIndex = index - 1,
      }
    else
      result.warnings[#result.warnings + 1] =
          string.format("Queue entry %d could not be read.", index - 1)
    end
  end

  if #result.pets == 0 then
    return nil, "The levelling queue contains no valid pets."
  end

  return result
end

function ImportExportService:PrepareLevellingQueueImport(value)
  local document, errorMessage = self:ParseLevellingQueue(value)

  if not document then
    return nil, errorMessage
  end

  local queueService = addon.Services
      and addon.Services.LevellingQueue

  if not queueService then
    return nil, "Levelling queue service is not available."
  end

  local unavailablePets = {}

  for _, petGUID in ipairs(queueService:GetAll()) do
    unavailablePets[petGUID] = true
  end

  local result = {
    document = document,
    pets = {},
    total = #document.pets,
    addable = 0,
    unavailable = 0,
    invalid = 0,
    warnings = document.warnings or {},
  }

  for _, entry in ipairs(document.pets) do
    local petGUID, pet = ResolveLevellingQueuePet(entry, unavailablePets, queueService)

    --------------------------------------------------
    -- No unused instance of this species exists.
    --------------------------------------------------

    if not petGUID then
      result.pets[#result.pets + 1] = {
        entry = entry,
        status = "unavailable",
      }

      result.unavailable = result.unavailable + 1
    else
      ------------------------------------------------
      -- Let the queue service perform the final
      -- validation.
      ------------------------------------------------
      local allowed, reason = queueService:CanAdd(petGUID)

      if allowed then
        result.pets[#result.pets + 1] = {
          entry = entry,
          petGUID = petGUID,
          pet = pet,
          status = "add",
          sourceIndex = entry.sourceIndex,
        }

        result.addable = result.addable + 1
      else
        result.pets[#result.pets + 1] = {
          entry = entry,
          petGUID = petGUID,
          pet = pet,
          status = "invalid",
          reason = reason,
          sourceIndex = entry.sourceIndex,
        }

        result.invalid = result.invalid + 1
      end
    end
  end

  return result
end

function ImportExportService:SortLevellingQueueImport(preview, sortMode)
  if type(preview) ~= "table" or type(preview.pets) ~= "table" then
    return false
  end

  sortMode = sortMode or "original"

  if sortMode == "original" then
    table.sort(
      preview.pets,
      function(left, right)
        return
            (left.entry.sourceIndex or 0) < (right.entry.sourceIndex or 0)
      end
    )

    return true
  end

  local function GetPetValue(item, field)
    local pet = item.pet

    if not pet then
      return 0
    end

    return tonumber(pet[field]) or 0
  end

  table.sort(
    preview.pets,
    function(left, right)
      ------------------------------------------------
      -- Keep unavailable/invalid entries after the
      -- actual importable pets.
      ------------------------------------------------
      local leftAdd = left.status == "add"
      local rightAdd = right.status == "add"

      if leftAdd ~= rightAdd then
        return leftAdd
      end

      ------------------------------------------------
      -- Rarity
      ------------------------------------------------
      if sortMode == "rarityHigh" then
        local leftValue = GetPetValue(left, "quality")
        local rightValue = GetPetValue(right, "quality")

        if leftValue ~= rightValue then
          return leftValue > rightValue
        end
      elseif sortMode == "rarityLow" then
        local leftValue = GetPetValue(left, "quality")
        local rightValue = GetPetValue(right, "quality")

        if leftValue ~= rightValue then
          return leftValue < rightValue
        end

        ------------------------------------------------
        -- Level
        ------------------------------------------------
      elseif sortMode == "levelHigh" then
        local leftValue = GetPetValue(left, "level")
        local rightValue = GetPetValue(right, "level")

        if leftValue ~= rightValue then
          return leftValue > rightValue
        end
      elseif sortMode == "levelLow" then
        local leftValue = GetPetValue(left, "level")
        local rightValue = GetPetValue(right, "level")

        if leftValue ~= rightValue then
          return leftValue < rightValue
        end

        ------------------------------------------------
        -- Pet type
        ------------------------------------------------
      elseif sortMode == "petType" then
        local leftValue = GetPetValue(left, "petType")
        local rightValue = GetPetValue(right, "petType")

        if leftValue ~= rightValue then
          return leftValue < rightValue
        end
      end

      ------------------------------------------------
      -- Stable fallback.
      ------------------------------------------------
      return (left.entry.sourceIndex or 0) < (right.entry.sourceIndex or 0)
    end
  )

  return true
end

function ImportExportService:ImportLevellingQueue(preview)
  if type(preview) ~= "table" or type(preview.pets) ~= "table" then
    return 0, "Invalid levelling queue import."
  end

  local queueService = addon.Services and addon.Services.LevellingQueue

  if not queueService then
    return 0, "Levelling queue service is not available."
  end

  local added = 0

  for _, item in ipairs(preview.pets) do
    if item.status == "add" and item.petGUID then
      local success = queueService:Add(item.petGUID)

      if success then
        added = added + 1
      end
    end
  end

  return added
end

addon.Services.ImportExport = ImportExportService
