local addonName, addon = ...

local Toolbar = {}
local DIALOG_WIDTH = 320

function Toolbar:Create(parent)
  local frame = addon.UI.Components.Panel:Create(parent, { width = DIALOG_WIDTH, height = 40 })
  self.Frame = frame
  self.Title =
      addon.UI.Components.Label:Create(
        frame,
        {
          text = "PetMatch",
          font = addon.UI.Theme.Fonts.Header,
          width = DIALOG_WIDTH - 24,
          justify = "CENTER",
        }
      )
  return frame
end

addon.UI.Views.Toolbar = Toolbar
