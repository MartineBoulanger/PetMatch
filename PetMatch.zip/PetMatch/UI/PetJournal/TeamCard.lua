local addonName, addon = ...

local TeamCard = {}

function TeamCard:Create(parent, team)
  local frame = CreateFrame("Button", nil, parent, "BackdropTemplate")
  frame:SetSize(320, 100)
  frame.team = team
  frame.selected = false
  frame:SetBackdrop({
    bgFile = "Interface/Tooltips/UI-Tooltip-Background",
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    edgeSize = 2,
  })
  frame:SetBackdropColor(0, 0, 0, 0)
  self:CreateText(frame)
  self:Update(frame)
  frame:SetScript(
    "OnClick",
    function()
      addon.EventBus:Fire(
        "TEAM_SELECTED",
        frame
      )
    end
  )
  frame:SetScript(
    "OnEnter",
    function()
      frame:SetAlpha(0.8)
    end
  )
  frame:SetScript(
    "OnLeave",
    function()
      frame:SetAlpha(1)
    end
  )
  return frame
end

function TeamCard:CreateText(frame)
  frame.Title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  frame.Title:SetPoint("TOPLEFT", 10, -10)
  frame.Pets = {}
  frame.PetIcons = {}
  for i = 1, 3 do
    local text = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    local icon = frame:CreateTexture(nil, "ARTWORK")
    icon:SetSize(42, 42)
    icon:SetPoint("TOPLEFT", 5 + ((i - 1) * 70), -35)
    text:SetPoint("TOP", icon, "BOTTOM", 0, -5)
    frame.Pets[i] = text
    frame.PetIcons[i] = icon
  end
end

function TeamCard:Update(frame)
  local team = frame.team
  frame.Title:SetText("⭐ " .. team.name)
  for i = 1, 3 do
    local petGUID = team.pets[i]
    print("[PetMatch]", petGUID)
    if petGUID then
      local info = { C_PetJournal.GetPetInfoByPetID(petGUID) }
      print("PetInfo returns:", unpack(info))
      if icon then
        frame.PetIcons[i]:SetTexture(icon)
        frame.PetIcons[i]:Show()
      end
      frame.Pets[i]:SetText(customName or name or "Unknown")
    else
      frame.PetIcons[i]:SetTexture(nil)
      frame.PetIcons[i]:Hide()
      frame.Pets[i]:SetText("Empty")
    end
  end
end

function TeamCard:SetSelected(frame, selected)
  frame.selected = selected
  if selected then
    frame:SetBackdropColor(0.2, 0.2, 0.2, 1)
  else
    frame:SetBackdropColor(0, 0, 0, 0.65)
  end
end

addon.UI.Components = addon.UI.Components or {}
addon.UI.Components.TeamCard = TeamCard
